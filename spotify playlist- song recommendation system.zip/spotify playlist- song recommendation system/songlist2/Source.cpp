#include<iostream>
#include<fstream>
#include<string>


using namespace std;
class list
{
    struct node
    {
    public:
       
        node* next;
        node* prev;
        string dance;
        string en;
        string ke;
        string loud;
        string speech;
        string acc;
        string inst;
        string dur;
        string gen;
        string st;
        int numOfLines;
        string data;

        //default and para. constructor
        node()
        {
            dance = " ";
            en = " ";
            ke = " ";
            loud = " ";
            speech = " ";
            acc = " ";
            inst = " ";
            dur = " ";
            gen = " ";

            st = " ";
            //  numOfLines 0;

        }
        node(string da, string e, string k, string l, string s, string a, string i, string d, string g, string st1)
        {

            dance = da;
            en = e;
            ke = k;
            loud = l;
            speech = s;
            acc = a;
            inst = i;
            dur = d;
            gen = g;
            st = st1;
        }


    };
    //link nodes
    node* head;
    node* tail;
    void removeDuplicates(node* start)
    {
        node* ptr1, * ptr2, * dup;
        ptr1 = start;
        while (ptr1 != NULL && ptr1->next != NULL)
        {
            ptr2 = ptr1;

            while (ptr2->next != NULL)
            {

                if (ptr1->st == ptr1->next->st)
                {

                    dup = ptr2->next;
                    ptr2->next = ptr2->next->next;
                    delete(dup);
                }
                else
                    ptr2 = ptr2->next;
            }
            ptr1 = ptr1->next;
        }
    }
    void WIF(node* start) {
        //WIF=write in file code
        ofstream fout;
        cout << "\n\nENTER THE NAME OF THE FILE U WANT TO CREATE:\t";
        string fn;
        cin >> fn;
        fout.open(fn, ios::app);    //name of the new file u want to create
        string dance, en, ke, loud, speech, acc, dur, gen, st, inst;
        node* temp = start;
      //  cout << temp->acc << endl;
        //cout << "Print" << endl;
       // system("pause");
        fout << "DANCEABILITY,ENERGY,KEY,LOUDNESS,SPEECHNESS,ACCOUSTICS,INSTRUMENTS,DURATION,GENRE,SONG TITLE\n";  //all the coloumns name 
        while (temp) {
            //fout << "ajeeb" << ",";

            dance= temp->dance;        
            en = temp->en;
            ke = temp->ke;
            loud = temp->loud;
            speech = temp->speech;
            acc = temp->acc;
            inst = temp->inst;
            dur = temp->dur;
            gen = temp->gen;
            st = temp->st;
           
            fout << dance << ',';
            fout << en << ',';
            fout << ke << ',';
            fout << loud << ',';
            fout << speech << ',';
            fout << acc << ',';
            fout << inst << ',';
            fout << dur << ',';
            fout << gen << ',';
            fout << st;
            fout << "\n";

            temp = temp->next;

        }

        fout.close();
    }
public:
    void WIF()
    {
        WIF(head);

    }
    void removeDuplicates() { removeDuplicates(head); }
    list()   //constructor
    {
        head = nullptr;
        tail = nullptr;
    }
    node* createNode(string const da, string const e, string const k, string const l, string const s, string const a, string const i, string const d, string const  g, string const  st1)
    {
        node* temp = new node();
        temp->dance = da;
        temp->en = e;
        temp->ke = k;
        temp->loud = l;
        temp->speech = s;
        temp->acc = a;
        temp->inst = i;
        temp->dur = d;
        temp->gen = g;
        temp->st = st1;
        temp->next = nullptr;
        return temp;
    }
    void push(string const dance, string const en, string const ke, string const loud, string const speech, string const acc, string const inst, string const dur, string const  gen, string const  st) {
        if (head == nullptr) {
            head = tail = createNode(dance, en, ke, loud, speech, acc, inst, dur, gen, st);
            head->next = tail;
            tail->next = nullptr;
        }
        else {
            tail->next = createNode(dance, en, ke, loud, speech, acc, inst, dur, gen, st);
            tail = tail->next;
            tail->next = nullptr;
        }
    }
    void insertAtTail(string const dance, string const en, string const ke, string const loud, string const speech, string const acc, string const inst, string const dur, string const  gen, string const  st)
    {

        if (head->next == nullptr) {
            head = new node(dance, en, ke, loud, speech, acc, inst, dur, gen, st);
            head->next = nullptr;
        }
        else {
            node* temp = new node(dance, en, ke, loud, speech, acc, inst, dur, gen, st);
            temp->next = nullptr;

            node* curr = head;
            while (curr->next != nullptr)
                curr = curr->next;
            curr->next = temp;
        }
   


    }
    void insertAtFile(string const dance, string const en, string const ke, string const loud, string const speech, string const acc, string const inst, string const dur, string const  gen, string const  st, bool flag = true)
    {

        if (head->next == nullptr) {
            head = new node(dance, en, ke, loud, speech, acc, inst, dur, gen, st);
            head->next = nullptr;
        }
        else {
            node* temp = new node(dance, en, ke, loud, speech, acc, inst, dur, gen, st);
            temp->next = nullptr;

            node* curr = head;
            while (curr->next != nullptr)
                curr = curr->next;
            curr->next = temp;
        }
        if (flag) {
            ofstream fout;
            fout.open("Songs_sorted8.csv", ios::app);

            fout << dance << ',';
            fout << en << ',';
            fout << ke << ',';
            fout << loud << ',';
            fout << speech << ',';
            fout << acc << ',';
            fout << inst << ',';
            fout << dur << ',';
            fout << gen << ',';
            fout << st;
            fout << "\n";
            fout.close();
        }

    }

    void search1(string val) {


        node* temp = head;
        // temp = head;
        bool bl = false;

        while (temp != NULL && temp != tail) {
            if (temp->st == val) {

                cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t" << endl;
                cout << temp->st;
                bl = true;
                int m;
                cout << endl << "PRESS 1 TO SEE SONG INFO" << endl;
                cin >> m;
                if (m == 1)
                {
                    cout << "\n\t\tINFORMATION OF SONG CURRENTLY PLAYING >.<" << endl;

                    cout << "---------------------------------------" << endl;
                    cout << "DANCEABILITY:\t " << temp->dance << endl;
                    cout << "ENERGY:\t\t " << temp->en << endl;
                    cout << "KEY:    \t\t" << temp->ke << endl;
                    cout << "LOUDNESS:\t " << temp->loud << endl;
                    cout << "SPEECHINESS:\t " << temp->speech << endl;
                    cout << "ACCOUSTICS:\t " << temp->acc << endl;
                    cout << "INSTRUMENTS:\t " << temp->inst << endl;
                    cout << "DURATION:\t " << temp->dur << endl;
                    cout << "GENRE:\t " << temp->gen << endl;
                    cout << "---------------------------------------" << endl;
                    bl = true;
                }
                else if (m != 1)
                {
                    cout << "INCORRECT CHOICE >:(" << endl;
                    break;
                }
                break;
               
            }
            temp = temp->next;
        }
        if (bl == false)
        {
            cout << "SONG NOT FOUND :(" << endl << "TRY AGAIN LATER :)" << endl;
        }

        delete temp;



    }



    void search2(string val) {


        node* temp = head;
        // temp = head;
        bool bl = false;

        while (temp != NULL && temp != tail) {
            if (temp->st == val) {

                cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t" << endl;
                cout << temp->st;
                bl = true;              
            }
            temp = temp->next;
        }
        if (bl == false)
        {
            cout << "SONG NOT FOUND :(" << endl << "TRY AGAIN LATER :)" << endl;
        }

        delete temp;
    }

    void previous(string val)
    {
        node* temp = head;
        // temp = head;
      // bool bl = false;

        while (temp != NULL && temp != tail) {
            if (temp->next->st == val) {

                cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t";
                cout << temp->st;
             //  cout << "\n\tUPCOMMING NEXT\n";
                //node* p= temp->next->st;
              //  bl = true;
                break;
            }
            temp = temp->next;
        }
        int l;
        cout << endl << "YOUR CHOICE: ";
        cin >> l;
        if (l == 3)
        {
            exit();
        }
        if (l == 2)
        {
            next(temp->st);
        }
        if (l == 1)
        {
            repeat(val);
        }
        if (l == 4)
        {
            previous(temp->st);
        }
        delete temp;
    }


    void next(string val)
    {
        node* temp = head;
        // temp = head;
      // bool bl = false;

        while (temp != NULL && temp != tail) {
            if (temp->st == val) {

                cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t";
                cout << temp->next->st;
                //node* p= temp->next->st;
              //  bl = true;
                break;
            }
            temp = temp->next;
        }
        cout << "\n\n\t\tPRESS 1- TO REPEAT\n\t\tPRESS 2- TO MOVE TO NEXT SONG\n\t\tPRESS 3- TO EXIT:\n\t\tPRESS 4- TO PLAY PREVIOUS\n\tYOUR CHOICE: ";
        int l;
        cin >> l;
        if (l == 3)
        {
            exit();
        }
        if (l == 2)
        {
            next(temp->next->st);
        }
        if (l == 1)
        {
            repeat(val);
        }
        if (l == 4)
        {
            previous(temp->next->st);
        }
       
    }
    
    void exit()
    {
        system("pause");
    }


    void repeat(string val)
    {
        cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t";
        cout << val<<endl;
        cout << "\n\n\t\tPRESS 1- TO REPEAT\n\t\tPRESS 2- TO MOVE TO NEXT SONG\n\t\tPRESS 3- TO EXIT:\n\t\tPRESS 4- TO PLAY PREVIOUS\n\tYOUR CHOICE: ";
      //  int l;
        //cin >> l;
        int l;
      //  cout << "YOUR CHOICE: ";
        cin >> l;
        if (l == 3)
        {
            exit();
        }
        if (l == 2)
        {
            next(val);
        }
        if (l == 1)
        {
            repeat(val);
        }
        if (l == 4)
        {
            previous(val);
        }
    }

    void search3(string val) {
        node* temp = head;
        // temp = head;
        bool bl = false;
        int choice = 0;
        while (temp != NULL && temp != tail) {
            if (temp->st == val) {

                cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t";
                cout << temp->st;
                bl = true;
                cout << "\n\n\t\tPRESS 1- TO REPEAT\n\t\tPRESS 2- TO MOVE TO NEXT SONG\n\t\tPRESS 3- TO EXIT:\n\t\tPRESS 4- TO PLAY PREVIOUS\n\tYOUR CHOICE: ";
                int l;
                cin >> l;

                if(l==1)
                {
                    cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t";
                    cout << temp->st<<endl;
                    cout << "YOUR CHOICE: ";
                    cin >> l;
                    if (l == 1)
                    {
                      repeat(val);
                    }
                   

                    choice++;
                }
                if (l == 2)
                {
                    cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t";
                    cout << temp->next->st;
                    int m;
                    cout << endl << "PRESS 1 TO SEE SONG INFO" << endl;
                    cin >> m;
                    if (m == 1)
                    {
                        cout << "\n\t\tINFORMATION OF SONG CURRENTLY PLAYING >.<" << endl;

                        cout << "---------------------------------------" << endl;
                        cout << "DANCEABILITY:\t " << temp->dance << endl;
                        cout << "ENERGY:\t\t " << temp->en << endl;
                        cout << "KEY:    \t\t" << temp->ke << endl;
                        cout << "LOUDNESS:\t " << temp->loud << endl;
                        cout << "SPEECHINESS:\t " << temp->speech << endl;
                        cout << "ACCOUSTICS:\t " << temp->acc << endl;
                        cout << "INSTRUMENTS:\t " << temp->inst << endl;
                        cout << "DURATION:\t " << temp->dur << endl;
                        cout << "GENRE:\t " << temp->gen << endl;
                        cout << "---------------------------------------" << endl;
                        bl = true;
                    }
                    else if (m != 1)
                    {
                        cout << "INCORRECT CHOICE >:(" << endl;
                        break;
                    }
                }
                if (l == 3)
                {
                    break;
                }

                if (l == 4)
                {
                    previous(val);
                }

            }
            temp = temp->next;
        }
        if (bl == false)
        {
            cout << "SONG NOT FOUND :(" << endl << "TRY AGAIN LATER :)" << endl;
        }


       // delete temp;
    }

    void search4() {

        //cout << "check";
        string val;
        cin >> val;
       // cout << "check";
        node* temp = head->next;
        // temp = head;
        bool bl = false;
        int choice = 0;
        while (temp != NULL && temp != tail) {
            if (temp->st == val) {

                cout << endl << "\t\t\tSONG CURENTLY PLAYING:\t";
                cout << temp->st;
                bl = true;
                int m;
                cout << endl << "PRESS 1 TO SEE SONG INFO" << endl;
                cin >> m;
                if (m == 1)
                {
                    cout << "\n\t\tINFORMATION OF SONG CURRENTLY PLAYING >.<" << endl;

                    cout << "---------------------------------------" << endl;
                    cout << "DANCEABILITY:\t " << temp->dance << endl;
                    cout << "ENERGY:\t\t " << temp->en << endl;
                    cout << "KEY:    \t\t" << temp->ke << endl;
                    cout << "LOUDNESS:\t " << temp->loud << endl;
                    cout << "SPEECHINESS:\t " << temp->speech << endl;
                    cout << "ACCOUSTICS:\t " << temp->acc << endl;
                    cout << "INSTRUMENTS:\t " << temp->inst << endl;
                    cout << "DURATION:\t " << temp->dur << endl;
                    cout << "GENRE:\t " << temp->gen << endl;
                    cout << "---------------------------------------" << endl;
                    bl = true;
                }
                else if (m != 1)
                {
                    cout << "INCORRECT CHOICE >:(" << endl;
                    break;
                }

            }
        }
    }
   //private:
    void deleteElement(string val) {   //checker function only
        node* ptr = head;
      //  cout << "Deleted h\n";
        while (ptr != NULL && ptr != tail) {
            if (ptr->st == val) {
                node* temp = ptr->next;
                ptr->next = temp->next;
                // temp->next->prev = ptr;
                delete temp;
               // cout << "Deleted\n";
            }

        }
        cout << "Not Found\n"; 

    }



    void reverselist(node* h)
    {
        node* prev = NULL, * curr = h, * next;

        while (curr) {
            next = curr->next;
            curr->next = prev;
            prev = curr;
            curr = next;
        }
        h = prev;
    }

    void rearrange()
    {
        node* slow = head, * fast = slow->next;
        while (fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
        }
        node* head1 = head;
        node* head2 = slow->next;
        slow->next = NULL;
        reverselist(head2);
        head = createNode(0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        node* curr = head;
        while (head1 || head2) {
            if (head1) {
                curr->next = head1;
                curr = curr->next;
                head1 = head1->next;
            }
            if (head2) {
                curr->next = head2;
                curr = curr->next;
                head2 = head2->next;
            }
        }
        head = head->next;
    }

    void printRandom()
    {
        if (head == NULL)
            return;

        srand(time(NULL));
        string r = head->st;

        node* current = head;
        int n;
        for (n = 2; current != NULL; n++)
        {            
            if (rand() % n == 0)
                r = current->st;
            current = current->next;
        }
        cout << "\n\nSong currently playing: \n" << r;
    }

    //void shuffle1()
    //{
    //    int s;
    //    cout << "Enter the size of array::";
    //    cin >> s;
    //    int randArray[s];
    //    for (int i = 0; i < s; i++)
    //        randArray[i] = rand() % 100;  //Generate number between 0 to 99

    //    cout << "\nElements of the array::" << endl;

    //    for (int i = 0; i < s; i++)
    //        cout << "Elements no " << i + 1 << "::" << randArray[i] << endl;

    //}



    void printList(void) {
        node* ptr = head;
        while (ptr) {
            std::cout << "\nDanceability: " << ptr->dance << '\n';
            std::cout << "ENERGY: " << ptr->en << '\n';
            std::cout << "KEY: " << ptr->ke << '\n';
            std::cout << "LOUDNESS: " << ptr->loud << '\n';
            std::cout << "SPEECHINESS: " << ptr->speech << '\n';
            std::cout << "ACCOUSTICNESS: " << ptr->acc << '\n';
            std::cout << "INSTRUMER: " << ptr->inst << '\n';
            std::cout << "DURATION: " << ptr->dur << '\n';
            std::cout << "GENERE: " << ptr->gen << '\n';
            std::cout << "SONG TITLE: " << ptr->st << '\n';
            std::cout << "-------------------" << '\n';
            ptr = ptr->next;
        }
    }


    void printList1(void) {
        node* ptr = head;
        while (ptr) {
            std::cout << "-------------------" << '\n';
            std::cout << "SONG TITLE: " << ptr->st << '\n';
            std::cout << "-------------------" << '\n';
            ptr = ptr->next;
        }
    }

     node* sorted = NULL;


    void sortedInsert( node* newnode)
    {

        if (sorted == NULL || sorted->dur >= newnode->dur) {
            newnode->next = sorted;
            sorted = newnode;
        }
        else {
                 node* current = sorted;
            while (current->next != NULL
                && current->next->dur < newnode->dur) {
                current = current->next;
            }
            newnode->next = current->next;
            current->next = newnode;

        }
    }

    void insertionsort()
    {
         node* current = head;
        while (current != NULL) {

             node* next = current->next;

            sortedInsert(current);

            current = next;

        }

        head = sorted;
    }


    node* sorted1 = NULL;

    void sortedInsert1(node* newnode)
    {

        if (sorted1 == NULL || sorted1->st >= newnode->st) {
            newnode->next = sorted1;
            sorted1 = newnode;
        }
        else {
            node* current = sorted1;
            while (current->next != NULL
                && current->next->st < newnode->st) {
                current = current->next;
            }
            newnode->next = current->next;
            current->next = newnode;

        }
    }

    void insertionsort1()
    {
        node* current = head;
        while (current != NULL) {

            node* next = current->next;

            sortedInsert1(current);

            current = next;

        }

        head = sorted1;
    }


private:
    void deleteAtHeadHelper() {
        node* ptr = head;
        head = head->next;
        tail->next = head;
        delete ptr;
    }
    void deleteAtTailHelper() {
        node* ptr = head;
        node* temp;
        while (ptr->next != tail)
            ptr = ptr->next;
        temp = ptr->next;
        ptr->next = head;
        tail = ptr;
        delete temp;
    }
    node* deleteHelper(string val) {
        node* ptr = head;
        while (ptr->next != tail && ptr) {
            if (val == ptr->next->st)
                return ptr;
            ptr = ptr->next;
        }
        return nullptr;
    }
public:
    void deleteNode(string val) {
        if (val == head->st)
            deleteAtHeadHelper();
        else if (val == tail->st)
            deleteAtTailHelper();
        else {
            node* prevptr = deleteHelper(val);
            if (prevptr) {
                node* temp = prevptr->next;
                prevptr->next = temp->next;
                delete temp;
               // cout << "deleted";

            }
        }
    }
    ~list()
    {
        head = NULL;
        tail = NULL;
        delete head;
        delete tail;
        // next = NULL;
    }

 /*   ~list()      //GIVING AN EXCEPTION
    {
        node* t = head;
        while (t != NULL)
        {
            node* temp = t;
            t = t->next;
            delete temp;
        }
    }*/
};



list reader(string file) {

    list temp;
    ifstream ip(file);
    if (!ip.is_open())
        cout << "File NOT Open" << '\n';

    string dec;
    string en;
    string ke;
    string loud;
    string speech;
    string acc;
    string inst;
    string dur;
    string gen;
    string st;
    int numOfLines = 0;

    getline(ip, dec, ',');
    getline(ip, en, ',');
    getline(ip, ke, ',');
    getline(ip, loud, ',');
    getline(ip, speech, ',');
    getline(ip, acc, ',');
    getline(ip, inst, ',');
    getline(ip, dur, ',');
    getline(ip, gen, ',');
    getline(ip, st);

    int i = 0;
    while (!ip.eof()) {   //!ip.eof()    i<51

        getline(ip, dec, ',');
        getline(ip, en, ',');
        getline(ip, ke, ',');
        getline(ip, loud, ',');
        getline(ip, speech, ',');
        getline(ip, acc, ',');
        getline(ip, inst, ',');
        getline(ip, dur, ',');
        getline(ip, gen, ',');
        getline(ip, st); 

        temp.push(dec, en, ke, loud, speech, acc, inst, dur, gen, st);
        numOfLines++;
        i++;
    }
    ip.close();
    return temp;
    cout << "okay" << endl;


    //for size;
    //int i = 0;
    //while (i < numOfLines) {

    //    getline(ip, dec, ',');
    //    getline(ip, en, ',');
    //    getline(ip, ke, ',');
    //    getline(ip, loud, ',');
    //    getline(ip, speech, ',');
    //    getline(ip, acc, ',');
    //    getline(ip, inst, ',');
    //    getline(ip, dur, ',');
    //    getline(ip, gen, ',');
    //    getline(ip, st);

    //    i++;
     //}
    //    cout << i << endl;
   

}





int main()
{
    ////                       WELCOME TO SOPHIA'S DS ASSIGNMENT#1  SPOTIFY PLAYLIST (or atleat i tried it to be ;) )


    ///read the following instructions on HOW TO USE MY APP

           /// NOTE:  USERNAME CAN BE ANY
           ///         PASSWORD: hi
           ///  enter this password after one action is done for the menu to appear again


   /// SIDE NOTE: T_T

  
    //DELETE AND SEARCH ARE WORKING FINE//
    

    //(just making a compiler exception sometimes in if statements below in menu for console list)  
                       // working fine in file //
                       
    //to check for console
   //uncomment the following lines of code


    string fileName = "Songs Information.csv";  ///name of the original file u want to use
    list one = reader(fileName);


    //int O,O1;
    //     one.search1("Funky Cold Medina");
    //     cout << endl << "press 11 to delete this song\t";
    //     cin >> O;
    //     if (O == 1)
    //     {
    //         one.deleteNode("Funky Cold Medina");
    //     }
    //     cout << "deleted";
    //     cout << endl;
    //   ////song would have been deleted now
    //     cout << endl << "press 1 to see if its deleted\t";
    //     cin >> O1;
    //     if (O1 == 1)
    //     {
    //         one.search1("Funky Cold Medina");
    //     }
    //     
    //        system ("pause");


    ////UNCOMMENT JUST TILL HERE TO CHECK DELETE AND SEARCH
   ////--------------------------------------------------/////


    ///  COMMENT THEM BACK AND ENJOY THE REST OF THE APP :)   ////









    /* string fileName = "Songs Information.csv";
    list one = reader(fileName);*/

    int choice = 0;
    string hi;
    cout << "                             WELCOME TO SOPHIA'S PLAYLIST >.< " << endl << endl;
    string user;
    cout << "ENTER YOUR NAME" << endl;
    cin >> user;
    cout << "ENTER YOUR PASSWORD TO OPEN THE APP " << endl;  //password==hi


    for (int i = 0; i < 10; i++)
    {
        cin >> hi;
        if (hi == "HI" || hi == "hi" || hi == "Hi")
        {

            cout << "\n-------------------------------" << endl;
            cout << endl << "                                  WELCOME " << user << "!! ;)" << endl << endl;
            cout << "ENTER YOUR CHOICE TO START PLAYING WITH THE PLAYLIST :D" << endl;
            cout << endl << "------------------------------" << endl;


            cout << "0- PRESS 0 TO SEE THE DETAILS OF SONG" << endl;
            cout << "1- PRESS 1 TO INSERT A SONG: " << endl;
            cout << "2- PRESS 2 TO DELETE A SONG: " << endl;
            cout << "3- PRESS 3 TO SHUFLLE THE PLAYLIST AND PLAY A RANDOM SONG: " << endl;
            cout << "4- PRESS 4 TO SORT THE LIST: " << endl;
            cout << "5- PRESS 5 TO PLAY A SONG FROM THE LIST: " << endl;
            cout << "6- PRESS 6 TO REMOVE DUPLICATE SONGS: " << endl;
            cout << "7- PRESS 7 TO SEARCH A SONG IN FILE: " << endl;
            cout << "8- PRESS 8 TO MOVE TO THE NEXT SONG:" << endl;
            cout << "9- PRESS 9 TO SHOW PLAYLIST:" << endl;
            cout << "10- PRESS 10 TO EXIT THE PLAYLIST:" << endl;
            cout << "-------------------------------" << endl << endl;

            cout << "YOUR CHOICE  ";
            cin >> choice;
            cout << endl;
            if (choice >= 0 && choice < 10)
            {

                if (choice == 0)
                {
                    cout << endl << "ENTER SONG NAME TO SEE ITS INFO " << endl;
                    string info;
                    cin >> info;
                    one.search1(info);

                     //one.printList();

                    cout << endl << endl << "enter hi to show menu again" << endl;                 
                }

                if (choice == 1)
                {
                    //insert function
                    int d;
                 
                        string dec;
                        string en;
                        string ke;
                        string loud;
                        string speech;
                        string acc;
                        string inst;
                        string dur;
                        string gen;
                        string st;
                        cout << "ENTER SONG TITLE\n";
                        cin >> st;
                        cout << "PLEASE ALSO ENTER ITS INFORMATION" << endl;
                        cout << endl << "------------------------------" << endl;
                        cout << "ENTER SONG DANCEABILITY\n";
                        cin >> dec;
                        cout << "ENTER SONG ENERGY\n";
                        cin >> en;
                        cout << "ENTER SONG KEY\n";
                        cin >> ke;
                        cout << "ENTER SONG LOUDNESS\n";
                        cin >> loud;
                        cout << "ENTER SONG SPEECH\n";
                        cin >> speech;
                        cout << "ENTER SONG ACOUSTICS\n";
                        cin >> acc;
                        cout << "ENTER SONG INSTRUMENTALNESS\n";
                        cin >> inst;
                        cout << "ENTER SONG DURATION\n";
                        cin >> dur;
                        cout << "ENTER SONG GENRE\n";
                        cin >> gen;
                        cout << endl << "------------------------------" << endl;
                        //  bool l = true;
                        //string fileName = "Songs Information.csv";
                       // list one = reader(fileName);
                        int t = 0;
                        one.insertAtTail(dec, en, ke, loud, speech, acc, inst, dur,gen,st);
                        cout << endl << "SONG INSERTED SUCCESSFULLY\n";
                        cout << "PRESS 1- TO SEE THE LIST: \n";
                        cout << "PRESS 2- TO SAVE IN FILE: \t";
                        cout << "\nYOUR CHOICE:\t";
                        cin >> t;
                        if (t == 1)
                        {
                            one.printList();
                        }

                        if (t == 2)
                        {
                            //  one.insertAtFile("0.983", "0.768", "7", "-10.336", "0.0904", "0.0308", "0", "97960", "pop", "dua lipa", true);
                            one.WIF();
                            cout << endl << "SONG SUCCESSFULLY INSERTED" << endl;
                        }
                   // }

                    cout << endl << endl << "enter hi to show menu again" << endl;
                }


                if (choice == 2)
                {
                    string delsong;
                    cout << "ENTER THE NAME OF THE SONG YOU WANT TO DELETE:\t";
                    cin >> delsong;
                    one.deleteNode(delsong);
                    cout << "SONG SUCCESSFULLY DELETED";
                    //delete function
                    cout << endl;                   
                    int t = 0;
                  //  cout << endl << "SONG INSERTED SUCCESSFULLY\n";
                    cout << "PRESS 1- TO SEE THE LIST: \n";
                    cout << "PRESS 2- TO SAVE IN FILE: \t";
                    cout << "\nYOUR CHOICE:\t";
                    cin >> t;
                    if (t == 1)
                    {
                        one.printList();
                        //cout << endl << endl << "enter hi to show menu again" << endl;
                    }

                    if (t == 2)
                    {
                        //  one.insertAtFile("0.983", "0.768", "7", "-10.336", "0.0904", "0.0308", "0", "97960", "pop", "dua lipa", true);
                        one.WIF();
                        cout << endl << "SAVED IN FILE SUCCESSFULLY:" << endl;
                        //cout << endl << endl << "enter hi to show menu again" << endl;
                    }
                    cout << endl << endl << "enter hi to show menu again" << endl;
                }
                if (choice == 3)
                {
                   // one.rearrange();
                    one.printRandom();
                    cout << endl;
                    cout << "\nPRESS 1- TO SEE THE LIST: \t";
                    cout << "\nPRESS 2- TO SAVE IN THE FILE: \t";
                    cout << "\nYOUR CHOICE:\t";
                    int t = 0;
                    cin >> t;
                    if (t == 1)
                    {
                        one.printList();
                        // one.WIF();
                    }
                    cout << endl;
                    if (t == 2)
                    {
                        one.WIF();
                        cout << endl << "SAVED IN FILE SUCCESSFULLY:" << endl;
                    }
                    cout << endl;

                    cout << endl << endl << "enter hi to show menu again" << endl;
                }
                if (choice == 4)
                {
                    int c1, c;
                    cout << "CHOOSE THE TYPE OF SORTING YOU WANT";
                    cout << endl << "    1-BY DURATION" << endl;
                    cout << endl << "    2-BY NAME" << endl;
                    cout << "\nYOUR CHOICE:\t";
                    cin >> c1;
                    if (c1 == 1)
                    {
                        cout <<endl<< "THIS MAY TAKE A WHILLE :("<<endl;
                       // one.bubbleSort();
                        one.insertionsort();
                        cout << "\t\t\tLIST SUCCESFULY SORTED :D\n";
                        int t;
                        cout << "\nPRESS 1- TO SEE THE LIST: \t";
                        cout << "\nPRESS 2- TO SAVE IN THE FILE: \t";
                        cout << "\nYOUR CHOICE:\t";
                        cin >> t;
                        if (t == 1)
                        {
                            one.printList();
                           // one.WIF();

                        }
                        cout << endl;
                        if (t == 2)
                        {                         
                            one.WIF();
                            cout << endl << "SAVED IN FILE SUCCESSFULLY:" << endl;
                        }
                        cout << endl;
                        
                      
                        cout << endl << endl << "enter hi to show menu again" << endl;
                    }
                    if (c1 == 2)
                    {
                        //sorting by name
                        cout << endl << "THIS MAY TAKE A WHILLE :(" << endl;
                        one.insertionsort1();
                        cout << "\t\t\tLIST SUCCESFULY SORTED :D\n";
                        cout << "\nPRESS 1- TO SEE THE LIST: \t";
                        cout << "\nPRESS 2- TO SAVE IN THE FILE: \t";
                        cout << "\nYOUR CHOICE:\t";
                        int t;
                        cin >> t;
                        if (t == 1)
                        {
                           // one.printList1();
                            //cout << "do u want to sort the list?:";
                            one.insertionsort1();
                          
                            one.removeDuplicates();
                            one.printList1();
                            //cout << endl << endl << "enter hi to show menu again" << endl;
                        }

                        if (t == 2)
                        {
                            //  one.insertAtFile("0.983", "0.768", "7", "-10.336", "0.0904", "0.0308", "0", "97960", "pop", "dua lipa", true);
                            one.WIF();
                            cout << endl << "SAVED IN FILE SUCCESSFULLY:" << endl;
                            //cout << endl << endl << "enter hi to show menu again" << endl;
                        }
                        cout << endl << endl << "enter hi to show menu again" << endl;
                    }

                }
                if (choice == 5)
                {
                    cout << "ENTER CHOICE" << endl;
                    int c2 = 0;
                   
                   cout << endl << "    1-PLAY A SONG ON DEMAND" << endl;
                   cout << endl << "    2-PLAY A SONG ON REPEAT" << endl;
                   cout << "\nYOUR CHOICE:\t";
                    cin >> c2;
                    // cout<<endl<< "      3-PLAY A SONG ON "
                    if (c2 == 1)
                    {
                        //search function
                        string val;
                        cout << "\nENTER SONG YOU WANT TO PLAY: \t";
                        cin >> val;
                        one.search1(val);
                        cout << endl << endl << "enter hi to show menu again" << endl;

                    }
                    if (c2 == 2)
                    {
                        string val;
                        cout << "\nENTER SONG YOU WANT TO PLAY: \t";
                        cin >> val;
                        one.search3(val);
                        //repeat function
                        cout << endl << endl << "enter hi to show menu again" << endl;
                    }

                }
                if (choice == 6)
                {
                    //removing duplicates
                    cout << endl << "IT WILL TAKE SOME TIME :( SORRY FOR THE INCONVINIENCE ;)" << endl;
                    one.removeDuplicates();
                    cout << "Duplicates removed" << endl;
                    int x = 0;
                    cout << endl << "ENTER 1 TO SEE THE LIST : ";
                    cout << endl << "ENTER 2 TO SAVE DATA IN FILE : \n";
                    cout << "\nYOUR CHOICE:\t";

                    cin >> x;
                    if (x == 1)
                    {
                        one.printList();
                        cout << endl << endl << "enter hi to show menu again" << endl;
                    }

                    if (x == 2)
                    {
                        one.WIF();
                        cout << endl << "SAVED IN FILE SUCCESSFULLY:" << endl;
                    }
                   // one.WIF(dec, en, ke, loud, speech, acc, inst, dur, gen, st);
                    cout << endl << endl << "enter hi to show menu again" << endl;
                }
                if (choice == 7)
                {
                    //searching
                    string searchsong;
                    cout << "ENTER THE NAME OF THE SONG YOU WANT TO PLAY";
                    cin >> searchsong;
                    one.search1(searchsong);
                   // one.search1("Just Like Me");
                    cout << endl << endl << "enter hi to show menu again" << endl;
                }
                if (choice == 8)
                {
                    string searchsong;
                    cout << "ENTER THE NAME OF THE SONG YOU ARE CURRENTLY LISTENING TO: ";
                    cin >> searchsong;
                    cout << "MOVED TO THE NEXT CHECK:"<<endl;
                     one.next(searchsong);
                    cout << endl << endl << "enter hi to show menu again" << endl;
                }
                if (choice == 9)
                {
                    cout << "HERE IS THE LIST OF SONGS:\n";
                    one.printList1();
                    cout << endl;
                    cout << endl << endl << "enter hi to show menu again" << endl;
                }
                if (choice == 10)
                {
                    cout << endl << "                       SAD TO SEE YOU GO ;(" << endl << "                  UNTIL NEXT TIME!! TAKE CARE!! :D" << endl;
                    //   cout << endl << endl << "enter hi to show menu again" << endl;
                    system("pause");
                }

               // cout << endl << endl << "enter hi to show menu again" << endl;
            }
            //continue;
           // cout << endl << endl << "enter hi to show menu again" << endl;
        }




        else if (i == 1 && (hi != "HI" && hi != "hi" && hi != "Hi"))
        {
            cout << "INCORRECT PASSWORD PLEASE TRY AGAIN" << endl;
           // cout << endl << endl << "enter hi to show menu again" << endl;
        }


        else if (i == 2 && (hi != "HI" && hi != "hi" && hi != "Hi"))
        {
            cout << endl << "               !!WARNING!!" << endl;
            cout << "INCORRECT PASSWORD ONLY 3 TRIES ALLOWED" << endl;
        }


        else if (i == 3 && (hi != "HI" && hi != "hi" && hi != "Hi"))
        {
            cout << "YOUR APP IS LOCKED >:(" << endl;
            system("pause");
           // exit();
         
        }
       // cout << endl << endl << "enter hi to show menu again" << endl;
    }


}